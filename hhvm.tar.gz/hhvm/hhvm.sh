#!/bin/bash


###Yum resource config
###EPL 
rm -f /etc/yum.repos.d/CentOS-*

wget -O /etc/yum.repos.d/CentOS-Base.repo http://192.168.249.130/CentOS-Base.6.2.repo
rpm -ivh http://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm
ping www.hop5.in -c 3
wget -O /etc/yum.repos.d/hop5.repo http://www.hop5.in/yum/el6/hop5.repo
yum clean all
yum -y erase boost
cd /etc/yum.repos.d/
mv /etc/yum.repos.d/hop5.repo /root/

### install relevent lib 
yum -y install git svn cpp make autoconf automake libtool patch memcached gcc-c++ cmake wget mysql-devel pcre-devel gd-devel libxml2-devel expat-devel libicu-devel bzip2-devel oniguruma-devel openldap-devel readline-devel libc-client-devel libcap-devel binutils-devel pam-devel elfutils-libelf-devel ImageMagick-devel libxslt-devel libevent-devel libcurl-devel libmcrypt-devel tbb-devel libdwarf-devel dbus-cxx-devel libunwind-devel php-mssql libtool libc-client-devel oniguruma-devel
mv /etc/yum.repos.d/epel* /root/
yum -y remove `rpm -qa |grep libevent`
yum -y remove ImageMagick
yum -y remove `rpm -qa |grep boost` 
yum -y remove `rpm -qa |grep openoffice`
mv /root/hop5.repo /etc/yum.repos.d/
rpm -ivh /root/soft/hhvm/liblcms2-2.4-1.el6.x86_64.rpm

##install hhvm nginx and memcached
yum -y install hhvm
nginx_v=`rpm -qa|grep nginx-[0-9].*|awk -F'-' '{print $1}'`
memcached_v=`rpm -qa|grep memcached-[0-9].*|awk -F'-' '{print $1}'`
if [ "$nginx_v" = "nginx" ]
   then 
     echo "nginx is installed"
   else
     echo "nginx is to be installed"
     yum -y install nginx
fi
mv /root/epel* /etc/yum.repos.d/
if [ "$memcached_v" = "memcached" ]
   then 
     echo "memcached is installed"
   else
     echo "memcached is to be installed"
     yum -y install memcached
fi

ln -s /usr/bin/hhvm /usr/bin/php
[ ! -d "/root/repo/" ] && mkdir -p /root/repo/
mv /etc/yum.repos.d/epel* /etc/yum.repos.d/hop5.repo /root/repo/


###update config file
cp -R /etc/nginx /etc/nginx_old
chown -R root:root /root/soft/hhvm/ 
cd /root/hhvm && chmod 755 *.sh
rsync -a /root/soft/hhvm/server.hdf /etc/hhvm/
rsync -a /root/soft/hhvm/config.hdf /etc/hhvm/  
rsync -a /root/soft/hhvm/nginx.conf /etc/nginx/
#rsync -a /root/soft/hhvm/virtual.conf /etc/nginx/conf.d/
rsync -a /root/soft/hhvm/fastcgi_params /etc/nginx/
#rsync -a /root/soft/hhvm/gzip.conf /etc/nginx/ 
[ ! -d /etc/nginx/sites-enabled/  ] && mkdir -p /etc/nginx/sites-enabled/
[ ! -d /var/www/test/ ] && mkdir -p /var/www/test/
rsync -a /root/soft/hhvm/test.conf /etc/nginx/sites-enabled/
rsync -a /root/soft/hhvm/index.php /var/www/test/
rsync -a /root/soft/hhvm/hhvm  /etc/init.d/

####start up nginx and hhvm

/etc/init.d/nginx start
/etc/init.d/hhvm start


